package kr.or.ddit.chating.servlet;

public interface IChatingServlet {

}
