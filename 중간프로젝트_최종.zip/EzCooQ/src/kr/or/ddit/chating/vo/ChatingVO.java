package kr.or.ddit.chating.vo;

public class ChatingVO {

}
