package kr.or.ddit.chating.dao;

public interface IChatingDao {

}
