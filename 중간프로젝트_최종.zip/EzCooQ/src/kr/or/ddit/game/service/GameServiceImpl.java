package kr.or.ddit.game.service;

public class GameServiceImpl implements IGameService {
	
}
