package kr.or.ddit.game.service;

public interface IGameService {

}
