package kr.or.ddit.game.vo;

public class GameVO {

}
