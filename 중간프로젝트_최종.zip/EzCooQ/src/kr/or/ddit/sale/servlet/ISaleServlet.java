package kr.or.ddit.sale.servlet;

public interface ISaleServlet {

}
