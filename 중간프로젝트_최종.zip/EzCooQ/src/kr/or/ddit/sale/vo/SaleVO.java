package kr.or.ddit.sale.vo;

public class SaleVO {

}
