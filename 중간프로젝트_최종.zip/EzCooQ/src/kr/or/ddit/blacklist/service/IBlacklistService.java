package kr.or.ddit.blacklist.service;

public interface IBlacklistService {

}
