package kr.or.ddit.blacklist.servlet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet("/viewBlacklist")
public class ViewBlacklistServlet extends HttpServlet{

}
