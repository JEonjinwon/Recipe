package kr.or.ddit.blacklist.dao;

public interface IBlacklistDao {

}
