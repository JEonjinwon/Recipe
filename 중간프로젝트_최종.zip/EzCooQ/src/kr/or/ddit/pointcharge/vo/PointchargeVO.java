package kr.or.ddit.pointcharge.vo;

public class PointchargeVO {

}
