package kr.or.ddit.pointcharge.service;

public interface IPointchargeService {

}
