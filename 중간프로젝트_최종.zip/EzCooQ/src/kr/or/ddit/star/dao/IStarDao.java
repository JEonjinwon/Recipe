package kr.or.ddit.star.dao;

public interface IStarDao {

}
