package kr.or.ddit.star.service;

public interface IStarService {

}
