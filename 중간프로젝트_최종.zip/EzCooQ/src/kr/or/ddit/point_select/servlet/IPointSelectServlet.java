package kr.or.ddit.point_select.servlet;

public interface IPointSelectServlet {

}
