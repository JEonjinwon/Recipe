package kr.or.ddit.point_select.vo;

public class PointSelectVO {

}
