package kr.or.ddit.point_select.dao;

public interface IPointSelectDao {

}
