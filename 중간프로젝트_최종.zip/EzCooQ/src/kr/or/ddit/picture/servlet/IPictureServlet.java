package kr.or.ddit.picture.servlet;

public interface IPictureServlet {

}
