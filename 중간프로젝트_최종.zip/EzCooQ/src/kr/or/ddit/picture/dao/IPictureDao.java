package kr.or.ddit.picture.dao;

public interface IPictureDao {

}
