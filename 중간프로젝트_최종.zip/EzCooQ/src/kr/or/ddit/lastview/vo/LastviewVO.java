package kr.or.ddit.lastview.vo;

public class LastviewVO {

}
