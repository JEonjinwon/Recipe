package kr.or.ddit.lastview.servlet;

public interface ILastviewServlet {

}
