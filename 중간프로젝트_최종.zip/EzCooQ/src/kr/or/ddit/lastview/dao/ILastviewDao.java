package kr.or.ddit.lastview.dao;

public interface ILastviewDao {

}
