package kr.or.ddit.bookmark.service;

public interface IBookmarkService {

}
