package kr.or.ddit.bookmark.dao;

public interface IBookmarkDao {

}
